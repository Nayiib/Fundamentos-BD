package Gui.AfiliadoBeneficiario;


public class ResulSoliCita {
    
}
