import Gui.*;

public class Main {

    public static void main(String[] args) {
        IniciarSesion Ventana = new IniciarSesion();
        Ventana.setVisible(true);
        Ventana.setLocationRelativeTo(null);
        
        
         
    }
}
